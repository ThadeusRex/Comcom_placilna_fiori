sap.ui.define([
	"sap/ui/base/ManagedObject",
	"sap/m/MessageBox",
	"./utilities",
	"sap/ui/core/routing/History"
], function (ManagedObject, MessageBox, Utilities, History) {

	var dialog_period;
	return ManagedObject.extend("com.sap.build.standard.template1.controller.Dialog1", {
		constructor: function (oView) {
			this._oView = oView;
			this._oControl = sap.ui.xmlfragment(oView.getId(), "com.sap.build.standard.template1.view.Dialog1", this);
			this._bInit = false;
		},

		exit: function () {
			delete this._oView;
		},

		getView: function () {
			return this._oView;
		},

		getControl: function () {
			return this._oControl;
		},

		getOwnerComponent: function () {
			return this._oView.getController().getOwnerComponent();
		},

		open: function () {
			var oView = this._oView;
			var oControl = this._oControl;

			if (!this._bInit) {

				// Initialize our fragment
				this.onInit();

				this._bInit = true;

				// connect fragment to the root view of this component (models, lifecycle)
				oView.addDependent(oControl);
			}

			var args = Array.prototype.slice.call(arguments);
			if (oControl.open) {
				oControl.open.apply(oControl, args);
			} else if (oControl.openBy) {
				oControl.openBy.apply(oControl, args);
			}
		},

		close: function () {
			this._oControl.close();
		},

		setRouter: function (oRouter) {
			this.oRouter = oRouter;

		},
		getBindingParameters: function () {
			return {};
		},

		setPeriod: function (oPeriod) {
			dialog_period = oPeriod;
		},

		_onButtonPress: function () {
			var text_pritozbe = this._oView.getController().byId("pritozba_text").getValue();

			if (text_pritozbe === "") {
				sap.m.MessageToast.show(this._oView.getModel("i18n").getResourceBundle().getText("dialogPrazen"), {
					duration: 2000,
					width: "15rem"
				});
				$(".sapMMessageToast").css("background", "#cc1919");
				return;
			}

			this._oView.getController().posljiPritozbo(dialog_period, text_pritozbe);
			this._oView.getController().byId("pritozba_text").setValue("");
			this.close();
		},
		_onButtonPress1: function () {
			this._oView.getController().byId("pritozba_text").setValue("");
			this.close();
		},
		onInit: function () {

			this._oDialog = this.getControl();

		},
		onExit: function () {
			this._oDialog.destroy();

		}

	});
}, /* bExport= */ true);