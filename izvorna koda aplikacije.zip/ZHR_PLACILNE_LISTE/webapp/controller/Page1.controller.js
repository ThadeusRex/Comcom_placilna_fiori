sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"./utilities",
	"./Dialog1",
	"sap/ui/core/routing/History",
	"sap/ui/model/odata/ODataUtils",
	"sap/ui/core/mvc/Controller",
	"sap/m/PDFViewer"
], function (BaseController, MessageBox, Utilities, Dialog1, History, ODataUtils, Controller, PDFViewer) {
	"use strict";

	return BaseController.extend("com.sap.build.standard.template1.controller.Page1", {
		handleRouteMatched: function (oEvent) {
			var oParams = {};
			if (oEvent.mParameters.data.context) {
				this.sContext = oEvent.mParameters.data.context;
			} else {
				if (this.getOwnerComponent().getComponentData()) {
					var patternConvert = function (oParam) {
						if (Object.keys(oParam).length !== 0) {
							for (var prop in oParam) {
								if (prop !== "sourcePrototype" && prop.includes("Set")) {
									return prop + "(" + oParam[prop][0] + ")";
								}
							}
						}
					};
					this.sContext = patternConvert(this.getOwnerComponent().getComponentData().startupParameters);
				}
			}

			var oPath;

			if (this.sContext) {
				oPath = {
					path: "/" + this.sContext,
					parameters: oParams
				};
				this.getView().bindObject(oPath);
			}
		},
		formatDateUTCtoLocale: function (dDate) {
			if (dDate) {
				return new Date(dDate.getUTCFullYear(), dDate.getUTCMonth(), dDate.getUTCDate());
			}
			return dDate;
		},
		_onDateRangeSelectionChange: function (oEvent) {
			var oDateRangeSelection = oEvent.getSource();
			var oBindingContext = oDateRangeSelection.getBindingContext();
			var sBindingPathOfDateValue = oDateRangeSelection.getBindingPath("dateValue");
			var sBindingPathOfSecondDateValue = oDateRangeSelection.getBindingPath("secondDateValue");
			var oFrom = oEvent.getParameter("from");
			if (oBindingContext && sBindingPathOfDateValue && oFrom) {
				var oFromBefore = oBindingContext.getModel().getProperty(sBindingPathOfDateValue, oBindingContext);
				if (oFromBefore) {
					var oUTCFrom = new Date(Date.UTC(oFrom.getFullYear(), oFrom.getMonth(), oFrom.getDate(), oFromBefore.getUTCHours(), oFromBefore.getUTCMinutes(),
						oFromBefore.getUTCSeconds()));
					oBindingContext.getModel().setProperty(sBindingPathOfDateValue, oUTCFrom, oBindingContext);
				}
			}
			var oTo = oEvent.getParameter("to");
			if (oBindingContext && sBindingPathOfSecondDateValue && oTo) {
				var oToBefore = oBindingContext.getModel().getProperty(sBindingPathOfSecondDateValue, oBindingContext);
				if (oToBefore) {
					var oUTCTo = new Date(Date.UTC(oTo.getFullYear(), oTo.getMonth(), oTo.getDate(), oToBefore.getUTCHours(), oToBefore.getUTCMinutes(),
						oToBefore.getUTCSeconds()));
					oBindingContext.getModel().setProperty(sBindingPathOfSecondDateValue, oUTCTo, oBindingContext);
				}
			}
		},
		onInit: function () {
			/*this.getOwnerComponent().getService("/sap/opu/odata/sap/ZHR_PLACILNE_FIORI_SRV/").then( // promise is returned
				function (oService) {}
			);*/
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.getTarget("Page1").attachDisplay(jQuery.proxy(this.handleRouteMatched, this));
			this.naloziPodatke();
		},

		pritozba: function (oEvent) {
			var sDialogName = "Dialog1";
			this.mDialogs = this.mDialogs || {};
			var oDialog = this.mDialogs[sDialogName];
			if (!oDialog) {
				oDialog = new Dialog1(this.getView());
				this.mDialogs[sDialogName] = oDialog;
				oDialog.setRouter(this.oRouter);
			}
			var bindingContext = oEvent.oSource.oPropagatedProperties.oBindingContexts;
			var path = bindingContext.oModelPlacilne.sPath;
			var oModel = this.getView().getModel("oModelPlacilne"); //Model();
			var oJSONDataSelected = oModel.getProperty(path);
			var oView = this.getView();

			if (oJSONDataSelected.Success === "") {
				sap.m.MessageToast.show(oView.getModel("i18n").getResourceBundle().getText("errorText"), {
					duration: 3000,
					width: "15rem"
				});
				$(".sapMMessageToast").css("background", "#cc1919");
				return;
			}
			var context = oEvent.getSource().getBindingContext();
			oDialog._oControl.setBindingContext(context);
			oDialog.setPeriod(oJSONDataSelected.Period);
			oDialog.open();
		},

		posljiPritozbo: function (oPeriod, textPritozbe) {
			var oDataModel = this.getOwnerComponent().getModel("odata_placilne");
			var pritozbaData = {
				Period: oPeriod,
				Pritozba2: textPritozbe
			};
			var oView = this.getView();
			oDataModel.create("/entity_pritozbaSet", pritozbaData, {
				success: function (response) {
					if (response.Success === "X") {
						sap.m.MessageToast.show(oView.getModel("i18n").getResourceBundle().getText("pritozbaSuccess"), {
							duration: 3000,
							width: "15rem"
						});
						$(".sapMMessageToast").css("background", "#007833");
					} else {
						var text;
						if (response.ErrorCode === "1") {
							text = oView.getModel("i18n").getResourceBundle().getText("pritozbaErrorZeArhivirana");
						} else {
							text = oView.getModel("i18n").getResourceBundle().getText("pritozbaError");
						}
						sap.m.MessageToast.show(text, {
							duration: 3000,
							width: "15rem"
						});
						$(".sapMMessageToast").css("background", "#cc1919");
					}
				},
				error: function (e) {
					sap.m.MessageToast.show(oView.getModel("i18n").getResourceBundle().getText("pritozbaError"), {
						duration: 3000,
						width: "15rem"
					});
					$(".sapMMessageToast").css("background", "#cc1919");
				}
			});
		},

		resetDatePicker: function (oEvent) {
			this.getView().byId("dateRange").setValue(null);
			this.naloziPodatke();
		},

		showPDF: function (oEvent) {
			var bindingContext = oEvent.oSource.oPropagatedProperties.oBindingContexts;
			var path = bindingContext.oModelPlacilne.sPath;
			var oModel = this.getView().getModel("oModelPlacilne"); //Model();
			var oJSONDataSelected = oModel.getProperty(path);
			var opdfViewer = new PDFViewer();
			this.getView().addDependent(opdfViewer);
			var sSource = "/sap/opu/odata/sap/ZHR_PLACILNE_FIORI_SRV/entity_prilogaSet(Filename='" + oJSONDataSelected.Period +
				".pdf',Period='" + oJSONDataSelected.Period + "')/$value";
			opdfViewer.setSource(sSource);
			opdfViewer.setTitle(this.getView().getModel("i18n").getResourceBundle().getText("dialogPredogledTitle"));
			opdfViewer.open();
		},

		posljiMail: function (oEvent) {
			var bindingContext = oEvent.oSource.oPropagatedProperties.oBindingContexts;
			var path = bindingContext.oModelPlacilne.sPath;
			var oModel = this.getView().getModel("oModelPlacilne"); //Model();
			var oJSONDataSelected = oModel.getProperty(path);
			var oDataModel = this.getOwnerComponent().getModel("odata_placilne");
			var oView = this.getView();
			if (oJSONDataSelected.Success !== "X") {
				sap.m.MessageToast.show("Plačilna lista še ni arhivirana!", {
					duration: 3000,
					width: "15rem"
				});
				$(".sapMMessageToast").css("background", "#cc1919");
				return;
			}

			var pritozbaData = {
				Period: oJSONDataSelected.Period
			};
			var text;
			oDataModel.create("/entity_mailSet", pritozbaData, {
				success: function (response) {
					if (response.Success === "X") {
						sap.m.MessageToast.show(oView.getModel("i18n").getResourceBundle().getText("mailSuccess"), {
							duration: 3000,
							width: "15rem"
						});
						$(".sapMMessageToast").css("background", "#007833");
					} else {
						if (response.ErrorCode === "1") {
							text = oView.getModel("i18n").getResourceBundle().getText("mailFail105");
						} else {
							text = oView.getModel("i18n").getResourceBundle().getText("mailFail");
						}
						sap.m.MessageToast.show(text, {
							duration: 3000,
							width: "25rem"
						});
						$(".sapMMessageToast").css("background", "#cc1919");
					}
				},
				error: function (e) {
					sap.m.MessageToast.show(oView.getModel("i18n").getResourceBundle().getText("mailFail"), {
						duration: 3000,
						width: "15rem"
					});
					$(".sapMMessageToast").css("background", "#cc1919");
				}
			});
		},

		buttonEnabledArhiviranje: function (oSuccess) {
			if (oSuccess === "X") {
				return true;
			} else {
				return false;
			}
		},

		iconSuccessdArhiviranje: function (oSuccess) {
			if (oSuccess === "X") {
				return "sap-icon://sys-enter-2";
			} else {
				return "sap-icon://alert";
			}
		},

		iconColorSuccessdArhiviranje: function (oSuccess) {
			if (oSuccess === "X") {
				return "Success";
			} else {
				return "Warning";
			}
		},

		hintSuccessdArhiviranje: function (oSuccess) {
			var oView = this.getView();
			if (oSuccess === "X") {
				return oView.getModel("i18n").getResourceBundle().getText("hintSuccess");
			} else {
				return oView.getModel("i18n").getResourceBundle().getText("hintError");
			}
		},

		naloziPodatke: function () {
			var oGlobalBusyDialog = new sap.m.BusyDialog();
			var BusyIndicator = sap.ui.core.BusyIndicator;
			BusyIndicator.show(0);
			var oView = this.getView();
			var oDataModel = this.getOwnerComponent().getModel("odata_placilne");
			var filterVal = "";
			var dateRange = oView.byId("dateRange");
			var begda = dateRange.getDateValue();
			var endda = dateRange.getSecondDateValue();

			if (begda !== null && endda !== null) {
				begda.setHours(12);
				endda.setHours(12);
			}
			var oBegdaFormatted = ODataUtils.formatValue(begda, "Edm.DateTime");
			var oEnddaFormatted = ODataUtils.formatValue(endda, "Edm.DateTime");
			filterVal = filterVal + "Begda eq " + oBegdaFormatted + " and Endda eq " + oEnddaFormatted;
			oDataModel.read("/entity_placillnaSet", {
				urlParameters: {
					"$filter": filterVal,
					"$top": "50"
				},
				success: function (response) {
					if (response !== undefined) {
						var oModelTemp = new sap.ui.model.json.JSONModel({
							data: response.results
						});
						oView.setModel(oModelTemp, "oModelPlacilne");
					}
					setTimeout(function () {
						oGlobalBusyDialog.close();
						BusyIndicator.hide(0);
					}, 1000);
				},
				error: function (e) {
					//sap.m.MessageToast.show(oView.getModel("i18n").getResourceBundle().getText("pageErrorPernrSearch"));
					setTimeout(function () {
						oGlobalBusyDialog.close();
						BusyIndicator.hide(0);
					}, 1000);
				}
			});
		}
	});
}, /* bExport= */ true);